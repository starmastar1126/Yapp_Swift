//
//  ServiciousVC.swift
//  Yapp
//
//  Created by eric on 2019/8/22.
//  Copyright © 2019 mx.yappapp.yapp. All rights reserved.
//

import UIKit

class ServiciousVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func onBackComida(_ sender: UIBarButtonItem) {
        self.navigationController!.popViewController(animated: true)
    }
}
