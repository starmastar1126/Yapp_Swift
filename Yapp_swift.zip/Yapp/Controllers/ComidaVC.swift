//
//  ComidaVC.swift
//  Yapp
//
//  Created by eric on 2019/8/22.
//  Copyright © 2019 mx.yappapp.yapp. All rights reserved.
//

import UIKit
import ImageSlideshow

class ComidaVC: UIViewController {

    @IBOutlet weak var imageSlider: ImageSlideshow!
    @IBOutlet weak var tacosBtn1: UIButton!
    @IBOutlet weak var tacosBtn2: UIButton!
    @IBOutlet weak var tacosBtn3: UIButton!
    @IBOutlet weak var tacosBtn4: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imageSlider.setImageInputs([
            ImageSource(image: UIImage(named: "slider_image1")!),
            ImageSource(image: UIImage(named: "slider_image2")!),ImageSource(image: UIImage(named: "slider_image3")!)])
        
        tacosBtn1.layer.borderWidth = 1
        tacosBtn1.layer.borderColor = UIColor.lightGray.cgColor
        tacosBtn2.layer.borderWidth = 1
        tacosBtn2.layer.borderColor = UIColor.lightGray.cgColor
        tacosBtn3.layer.borderWidth = 1
        tacosBtn3.layer.borderColor = UIColor.lightGray.cgColor
        tacosBtn4.layer.borderWidth = 1
        tacosBtn4.layer.borderColor = UIColor.lightGray.cgColor
        
        
        
//        let pageIndicator = UIPageControl()
//        pageIndicator.currentPageIndicatorTintColor = UIColor.lightGray
//        pageIndicator.pageIndicatorTintColor = UIColor.black
//        imageSlider.pageIndicator = pageIndicator
//        
//        imageSlider.pageIndicatorPosition = PageIndicatorPosition(horizontal: .left(padding: 20), vertical: .customBottom(padding: 10))
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.topItem?.title = "COMIDA"
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
    }

    @IBAction func onShowTacos(_ sender: UIButton) {
        performSegue(withIdentifier: "showTacosSegue", sender: self)
    }
}
